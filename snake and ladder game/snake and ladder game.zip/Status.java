/*
 Xu Zhou Hu 40167460
 Ali Zedan 40174606
 COMP 249 - Assignment #0 - Snake and Ladder
 Due Date: 9 Feb, 2021 (1-day extension given by Dr. Hanna)
 General explanation about the program: This program is a Snake and Ladder game which can be played by 2 to 4 players.
 First, the user will input the desired number of player for this game. However, if the number is not between 2 and 4,
 the user will have 4 attempts to correct the mistake or he/she will be locked out from the program. Second, the players
 will roll dice in order to determine the order in which they will play the game. If some rolls are ties, they will roll
 again until the program establish the playing order based on how big the roll value was. Finally, the game starts and
 players will take turn rolling dice to get to square 100 where they win the game: they must land exactly land on 100 or
 they will go back the value of extra roll. Of course, there are snakes and ladders so watch out!
 */
public class Status 
{
	private boolean notOver;
	//constructor 
    public Status()
    {
       notOver = true;
    }
    //accessor get the state of game (true means game not finished, false means game over)
    public boolean getStatus()
    {
       return notOver;
    }  
    //end game
    public void GameOver()
    {
       notOver = false;       
    }    
}