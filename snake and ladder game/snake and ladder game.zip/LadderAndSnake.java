/*
 Xu Zhou Hu 40167460
 Ali Zedan 40174606
 COMP 249 - Assignment #0 - Snake and Ladder
 Due Date: 9 Feb, 2021 (1-day extension given by Dr. Hanna)
 General explanation about the program: This program is a Snake and Ladder game which can be played by 2 to 4 players.
 First, the user will input the desired number of player for this game. However, if the number is not between 2 and 4,
 the user will have 4 attempts to correct the mistake or he/she will be locked out from the program. Second, the players
 will roll dice in order to determine the order in which they will play the game. If some rolls are ties, they will roll
 again until the program establish the playing order based on how big the roll value was. Finally, the game starts and
 players will take turn rolling dice to get to square 100 where they win the game: they must land exactly land on 100 or
 they will go back the value of extra roll. Of course, there are snakes and ladders so watch out!
 */
import java.util.Random;
public class LadderAndSnake 
{
	//private variables
	private int playernb;
    private int square = 0;
    //constructor with 1 parameter (playernb)
    public LadderAndSnake (int playernb)
    {
        this.playernb = playernb;
    }
    //accessor to get playernb and square
    public int getPlayerNb()
    {
        return playernb;
    }  
    public int getSquare()
    {
        return square;
    }
    //the flipDice() method will return a value between 1 and 6 randomly
    public int flipDice()
    {    	
	    int dice = new Random().nextInt(6)+1;
	    return dice;
	} 
    //the play method contains core mechanics of the game
    public void play (Status game)
    {
    	//check if game is over or not. if not then continue to play game
    	if (game.getStatus() == true)
    	{   	   
    		//flipDice() method to get the roll number
    		int roll = flipDice();
    		//if player lands on a square bigger than 100
    		//logic: example: player on square 96 and rolls 5. 100-(96+5-100)=100-1= 99 do player lands on square 99
            if (square + roll > 100)
            {
            	square = 100 - (square + roll - 100);                
            }
            //less then 100 then it's initial square + roll = final square
            else
            {
            	square = square + roll; 
            }
            //position, check for snakes or ladders then newposition
            int position = square;              
            Ladders();
            Snakes();                              
            int newposition = square; 
            //logic: after checking for snake or ladder the new position is the same it means that we didn't land on snake or ladder
            if (position == newposition)
            {
            	System.out.println("Player " + playernb + " got a dice value of " + roll + "; now in square " + square);
            }
            //logic: new position > old position, it means that we climed a ladder
            else if (position < newposition)
            {
                System.out.println("Player " + playernb + " got a dice value of " + roll + "; gone to square " + position + " then up to square " + newposition);
                System.out.println("Lucky :)");
            }
            //logic: new position < old position, it means that we got bitten by snake
            else if (position > newposition)
            {
                System.out.println("Player " + playernb + " got a dice value of " + roll + "; gone to square " + position + " then down to square " + newposition);
                System.out.println("Unlucky :(");
            }                
        }
    	//check if game is over
        checkStatus(game);
    }
    //ckeck for ladders
    public void Ladders()
    {
       if (square == 1)
       {
           square = 38;
       }
       else if (square == 4)
       {
           square = 14;
       }
       else if (square == 9)
       {
           square = 31;
       }
       else if (square == 21)
       {
           square = 42;
       }
       else if (square == 28)
       {
           square = 84;
       }
       else if (square == 36)
       {
           square = 44;
       }
       else if (square == 51)
       {
           square = 67;
       }
       else if (square == 71)
       {
           square = 91;
       }
       else if (square == 80)
       {
           square = 100;
       }
    } 
    //check for snakes
    public void Snakes()
    {
       if (square == 98)
       {
           square = 78;
       }
       else if (square == 97)
       {
           square = 76;
       }
       else if (square == 95)
       {
           square = 24;
       }
       else if (square == 93)
       {
           square = 68;
       }
       else if (square == 64)
       {
           square = 60;
       }
       else if (square == 62)
       {
           square = 19;
       }
       else if (square == 48)
       {
           square = 30;
       }
       else if (square == 16)
       {
           square = 6;
       }       
    }  
    //check if game is over
    public void checkStatus(Status game)
    {
    	//if player lands on square 100 then game is over
    	if (square == 100)
    	{
    		System.out.println("Player " + playernb + " has won the game! ");
    		//end message
    		System.out.println("---------------------------------------");
    		System.out.println("Thank you for playing Snake and Ladder!");
    		System.out.println("---------------------------------------");
    		//end game
            game.GameOver();
        }
    }
}
