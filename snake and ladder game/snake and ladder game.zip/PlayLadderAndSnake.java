/*
 Xu Zhou Hu 40167460
 Ali Zedan 40174606
 COMP 249 - Assignment #0 - Snake and Ladder
 Due Date: 9 Feb, 2021 (1-day extension given by Dr. Hanna)
 General explanation about the program: This program is a Snake and Ladder game which can be played by 2 to 4 players.
 First, the user will input the desired number of player for this game. However, if the number is not between 2 and 4,
 the user will have 4 attempts to correct the mistake or he/she will be locked out from the program. Second, the players
 will roll dice in order to determine the order in which they will play the game. If some rolls are ties, they will roll
 again until the program establish the playing order based on how big the roll value was. Finally, the game starts and
 players will take turn rolling dice to get to square 100 where they win the game: they must land exactly land on 100 or
 they will go back the value of extra roll. Of course, there are snakes and ladders so watch out!
 */
//function learnt in comp248 for dice roll
import java.util.Random;
//for user input
import java.util.Scanner;
//this is the DRIVER file
public class PlayLadderAndSnake 
{
	   //the main() method
	   public static void main(String[] args)
	   {
		    //welcome message
		    System.out.println("-----------------------------------------");
		    System.out.println("       Welcome to Snake and Ladder       ");
		    System.out.println("        Xu Zhou Hu and Ali Zedan         ");
		    System.out.println("-----------------------------------------");
		    //prompt user to enter number of player
			System.out.print("Enter the number of players for Ladder and Snake � Number must be between 2 and 4 inclusively: ");
			Scanner keyboard = new Scanner(System.in);
			int nbplayer = keyboard.nextInt();
			//declare variables
			int nbattempt = 1;
			boolean correctinput = false;
			//max attempt is 4
			while (nbattempt < 5)
			{								
				//terminate program after 4 tries
				if (nbattempt == 4 )
				{		
					System.out.println("Bad Attempt " + nbattempt + " - You have exhausted all your chances.");
					System.out.println("By not playing by the rules, you have been kicked out from the program.");
					break;
				}
				//if wrong number, ask user to enter again
				else if (!(nbplayer >=2 && nbplayer <=4))
				{							
					System.out.print("Bad Attempt " + nbattempt + " - Invalid number of players. ");
					System.out.print("Please enter a number between 2 and 4 inclusively: ");
					nbplayer = keyboard.nextInt();
					nbattempt += 1;
				}							
				else
				{
					correctinput = true;
					break; 
				}										
			}
			//if the player nb is between 2 and 4
			if (correctinput == true)
			{
				//2 player game
				if (nbplayer == 2) 
				{
					System.out.println("");
					System.out.println("Snake and Ladder game is played between 2 players.");
					System.out.println("Now deciding which player will start playing by dice rolls:");
					//objet status declaration to get state of game (finished or not)
					Status game = new Status();
					//array storing dice roll
					int dice[] = {0,0};
					dice[0]=new Random().nextInt(6)+1;
					dice[1]=new Random().nextInt(6)+1;
					System.out.println("Player 1 got a dice value of "+dice[0]);
					System.out.println("Player 2 got a dice value of "+dice[1]);
					int tiebreak = 1;
				//there can be infinite number of tie break
				while (tiebreak<100) 
				{
					//tiebreaker if the value player 1 rolled is the same as 2
					if (dice[0]==dice[1])
					{
						System.out.println("A tie was achieved between Player 1 and Player 2. Attempting to break the tie");
						tiebreak+=1;
						dice[0]=new Random().nextInt(6)+1;
						dice[1]=new Random().nextInt(6)+1;
						System.out.println("Player 1 got a dice value of "+dice[0]);
						System.out.println("Player 2 got a dice value of "+dice[1]);
					}
					//1>2 order player 1 player 2
					else if (dice[0]>=dice[1]) 
					{
						System.out.println("Reached final decision on order of playing: Player 1, Player 2");
						dice[0]=1;
						dice[1]=2;
						break;
					}
					//1<2 order player 2 player 1
					else
					{
						System.out.println("Reached final decision on order of playing: Player 2, Player 1");
						dice[0]=2;
						dice[1]=1;
						break;					
					}
				}
				    //object snake and ladder to create 2 player
					LadderAndSnake p1 = new LadderAndSnake(dice[0]);
					LadderAndSnake p2 = new LadderAndSnake(dice[1]);
					//if game is not over, continue
					while (game.getStatus() == true)
					{
						System.out.println("Please roll dice");
						//play() method for both players
						p1.play(game);
						p2.play(game);						
					}
				}
				//3 player game
				else if (nbplayer == 3) 
				{
					System.out.println("");
					System.out.println("Snake and Ladder game is played between 3 players.");
					System.out.println("Now deciding which player will start playing by dice rolls:");
					Status game = new Status();
					//dice roll array
					int dice[] = {0,0,0};
					dice[0]=new Random().nextInt(6)+1;
					dice[1]=new Random().nextInt(6)+1;					
					dice[2]=new Random().nextInt(6)+1;					
					System.out.println("Player 1 got a dice value of "+dice[0]);
					System.out.println("Player 2 got a dice value of "+dice[1]);
					System.out.println("Player 3 got a dice value of "+dice[2]);
					boolean notie=false;
					int tiebreak=1;
				while (tiebreak<100)					
				{    
					//if there is a tie (4 cases)
					if (dice[0]==dice[1]&&dice[1]==dice[2])
			        {			            
						System.out.println("A tie was achieved between Player 1, Player 2 and Player 3. Attempting to break the tie");
			            dice[0]=new Random().nextInt(6)+1;
			            dice[1]=new Random().nextInt(6)+1;
						dice[2]=new Random().nextInt(6)+1;
						System.out.println("Player 1 got a dice value of "+dice[0]);
						System.out.println("Player 2 got a dice value of "+dice[1]);
						System.out.println("Player 3 got a dice value of "+dice[2]);
			        }
			        else if (dice[1]==dice[2])
			        {
			            System.out.println("A tie was achieved between Player 2 and Player 3. Attempting to break the tie");
			            dice[1]=new Random().nextInt(6)+1;					
						dice[2]=new Random().nextInt(6)+1;						
						System.out.println("Player 2 got a dice value of "+dice[1]);
						System.out.println("Player 3 got a dice value of "+dice[2]);
			        }
			        else if (dice[0]==dice[2])
			        {
			            System.out.println("A tie was achieved between Player 1 and Player 3. Attempting to break the tie");
			            dice[0]=new Random().nextInt(6)+1;					
						dice[2]=new Random().nextInt(6)+1;
						System.out.println("Player 1 got a dice value of "+dice[0]);						
						System.out.println("Player 3 got a dice value of "+dice[2]);
			        }
			        else if (dice[0]==dice[1])
			        {
			        	System.out.println("A tie was achieved between Player 1 and Player 2. Attempting to break the tie");
			            dice[0]=new Random().nextInt(6)+1;					
						dice[1]=new Random().nextInt(6)+1;
						System.out.println("Player 1 got a dice value of "+dice[0]);
						System.out.println("Player 2 got a dice value of "+dice[1]);
			        }
					//if there isn't a tie
			        else
			        {	
			        	notie=true;
			        }
			        if (notie==true)
			        {	
			        	//get max number in array dice[] and get its index (player number, index 1 is player 1)
			        	int max = 0; int indexmax=0;
			        	//the logic is first dice[0]=max. if dice[1]>dice[0] then dice 1 becomes max
			        	for (int i = 0; i < dice.length-1; i++)
			        	{
			        		max = dice[i];			         
			            	for (int j = i+1; j < dice.length; j++) 
			            	{
			            		if (dice[j] < dice[i])
			            		{
			            		max = dice[j];
			            		//get index of maximum roll (index array dice[] =number player)
			            		indexmax=j;
			            		}
			            		else 
			            		{
			            		max = dice[i];
			            		indexmax=i;}
			            	}
			        	}
			        	//get min in dice[] and get index (playernb) same logic
			        	int min = 0; int indexmin=0; 			           
			        	for (int i = 0; i < dice.length-1; i++)
			        	{
			        		min = dice[i];			         
			            	for (int j = i+1; j < dice.length; j++) 
			            	{
			            		if (dice[j] > dice[i])
			            		{min = dice[j];
			            		indexmin=j;}
			            		else 
			            		{
			            		min = dice[i];
			            		indexmin=i;}
			            	}
			            }
			        	System.out.println("------------------------------------------------");
			        	System.out.println("Player "+indexmax+" play first");
			        	//get index of the middle player after getting index max and min
			        	int indexmid=0;
			        	//logic: if player 1 and 3 is either max or min, then player 2 must be in middle
			        	//same logic applies for 2 other cases
			        	if ((indexmin==1 && indexmax==3)||(indexmin==3 && indexmax==1))
			        	{
			        		indexmid=2; System.out.println("Player "+indexmid+" play second");
			        		}			        	
			        	else if ((indexmin==1 && indexmax==2)||(indexmin==2 && indexmax==1)) 
			        	{
			        		indexmid=3; System.out.println("Player "+indexmid+" play second");
			        		}
			        	else if ((indexmin==2 && indexmax==3)||(indexmin==3 && indexmax==2))
			        	{
			        		indexmid=1; System.out.println("Player "+indexmid+" play second");
			        		}
			        	//print player order
			        	System.out.println("Player "+indexmin+" play last");
					    System.out.println("Reached final decision on order of playing: Player "+indexmax+", Player "+indexmid+", Player "+indexmin);
					    //3 snakeandladder object for 3 player
					    LadderAndSnake p1 = new LadderAndSnake(indexmax);
						LadderAndSnake p2 = new LadderAndSnake(indexmid);
						LadderAndSnake p3 = new LadderAndSnake(indexmin);	
						//if game not over, continue game
					    while (game.getStatus() == true)
					    {
					    	//play() method
					    	System.out.println("Please roll dice");
					    	p1.play(game);
					        p2.play(game);
					        p3.play(game);				        
					    }
				    	break; 					            						            						   					            		
			    }
			}									        														
				}
				//4 player game
				else if (nbplayer == 4)
				{
					System.out.println("");
					System.out.println("Snake and Ladder game is played between 4 players.");
					System.out.println("Now deciding which player will start playing by dice rolls:");
					//rolling dice for 4 player + array storing roll value + print rol value they each got
					int dice[] = {0,0,0,0};
					dice[0]=new Random().nextInt(6)+1;
					dice[1]=new Random().nextInt(6)+1;					
					dice[2]=new Random().nextInt(6)+1;
					dice[3]=new Random().nextInt(6)+1;
					System.out.println("Player 1 got a dice value of "+dice[0]);
					System.out.println("Player 2 got a dice value of "+dice[1]);
					System.out.println("Player 3 got a dice value of "+dice[2]);
					System.out.println("Player 4 got a dice value of "+dice[3]);
					boolean notie=false;
					int tiebreak=1;
				while (tiebreak<100)					
				{    
					//breaking ties (10 cases)
					if (dice[0]==dice[1]&&dice[1]==dice[2])
			        {			            
						System.out.println("A tie was achieved between Player 1, Player 2 and Player 3. Attempting to break the tie");
			            dice[0]=new Random().nextInt(6)+1;
			            dice[1]=new Random().nextInt(6)+1;
						dice[2]=new Random().nextInt(6)+1;
						System.out.println("Player 1 got a dice value of "+dice[0]);
						System.out.println("Player 2 got a dice value of "+dice[1]);
						System.out.println("Player 3 got a dice value of "+dice[2]);
			        }
					else if (dice[1]==dice[2]&&dice[2]==dice[3])
			        {			            
						System.out.println("A tie was achieved between Player 2, Player 3 and Player 4. Attempting to break the tie");
			            dice[1]=new Random().nextInt(6)+1;
			            dice[2]=new Random().nextInt(6)+1;
						dice[3]=new Random().nextInt(6)+1;
						System.out.println("Player 2 got a dice value of "+dice[1]);
						System.out.println("Player 3 got a dice value of "+dice[2]);
						System.out.println("Player 4 got a dice value of "+dice[3]);
			        }
					else if (dice[0]==dice[2]&&dice[2]==dice[3])
			        {			            
						System.out.println("A tie was achieved between Player 1, Player 3 and Player 4. Attempting to break the tie");
			            dice[0]=new Random().nextInt(6)+1;
			            dice[2]=new Random().nextInt(6)+1;
						dice[3]=new Random().nextInt(6)+1;
						System.out.println("Player 1 got a dice value of "+dice[1]);
						System.out.println("Player 3 got a dice value of "+dice[2]);
						System.out.println("Player 4 got a dice value of "+dice[3]);
			        }
					else if (dice[1]==dice[2]&&dice[2]==dice[3])
			        {			            
						System.out.println("A tie was achieved between Player 1, Player 2 and Player 4. Attempting to break the tie");
			            dice[0]=new Random().nextInt(6)+1;
			            dice[1]=new Random().nextInt(6)+1;
						dice[3]=new Random().nextInt(6)+1;
						System.out.println("Player 1 got a dice value of "+dice[0]);
						System.out.println("Player 2 got a dice value of "+dice[1]);
						System.out.println("Player 4 got a dice value of "+dice[3]);
			        }
			        else if (dice[1]==dice[2])
			        {
			            System.out.println("A tie was achieved between Player 2 and Player 3. Attempting to break the tie");
			            dice[1]=new Random().nextInt(6)+1;					
						dice[2]=new Random().nextInt(6)+1;						
						System.out.println("Player 2 got a dice value of "+dice[1]);
						System.out.println("Player 3 got a dice value of "+dice[2]);
			        }
			        else if (dice[0]==dice[2])
			        {
			            System.out.println("A tie was achieved between Player 1 and Player 3. Attempting to break the tie");
			            dice[0]=new Random().nextInt(6)+1;					
						dice[2]=new Random().nextInt(6)+1;
						System.out.println("Player 1 got a dice value of "+dice[0]);						
						System.out.println("Player 3 got a dice value of "+dice[2]);
			        }
			        else if (dice[0]==dice[1])
			        {
			        	System.out.println("A tie was achieved between Player 1 and Player 2. Attempting to break the tie");
			            dice[0]=new Random().nextInt(6)+1;					
						dice[1]=new Random().nextInt(6)+1;
						System.out.println("Player 1 got a dice value of "+dice[0]);
						System.out.println("Player 2 got a dice value of "+dice[1]);
			        }
			        else if (dice[3]==dice[2])
			        {
			            System.out.println("A tie was achieved between Player 3 and Player 4. Attempting to break the tie");
			            dice[3]=new Random().nextInt(6)+1;					
						dice[2]=new Random().nextInt(6)+1;
						System.out.println("Player 3 got a dice value of "+dice[2]);						
						System.out.println("Player 4 got a dice value of "+dice[3]);
			        }
			        else
			        {	
			        	notie=true;
			        }
					//if no tie then same principle as 3 player, first get max and min and their index (player nb)
			        if (notie==true)
			        {	
			        	//get max and index max
			        	int max = 0; int indexmax=0; 			           
			        	for (int i = 0; i < dice.length-1; i++)
			        	{
			        		max = dice[i];			         
			            	for (int j = i+1; j < dice.length; j++) 
			            	{
			            		if (dice[j] < dice[i])
			            		{max = dice[j];
			            		indexmax=j;}
			            		else 
			            		{
			            		max = dice[i];
			            		indexmax=i;}
			            	}
			        	}
			        	int min = 0; int indexmin=0; 			           
			        	for (int i = 0; i < dice.length-1; i++)
			        	{
			        		min = dice[i];			         
			            	for (int j = i+1; j < dice.length; j++) 
			            	{
			            		if (dice[j] > dice[i])
			            		{min = dice[j];
			            		indexmin=j;}
			            		else 
			            		{
			            		min = dice[i];	
			            		indexmin=i;}
			            	}
			            }			        
			        	System.out.println("------------------------------------------------");
			        	System.out.println("Player "+indexmax+" play first");
			        	int index2=0; int index3=0;
			        	//the logic is this: if player 1 and 4 is either max or min, then player 2 and 3 must be in the middle
			        	if ((indexmin==1 && indexmax==4)||(indexmin==4 && indexmax==1))
			        	{
			        		//if the number player 2 rolled is bigger than player 3, then index2 is player 2 and index 3 is player 3
			        		if (dice[1]>dice[2])
			        		{
			        		index2=2;
			        		index3=3;
			        		System.out.println("Player "+index2+" play second");
			        		System.out.println("Player "+index3+" play third");
			        		}
			        		//if the number player 3 rolled is bigger than player 2, then index2 is player 3 and index 3 is player 2
			        		else if (dice[1]<dice[2])
			        		{
			        		index2=3;
			        		index3=2;
			        		System.out.println("Player "+index2+" play second");
			        		System.out.println("Player "+index3+" play third");
			        		}
			        	}
			        	//same logic applies for other cases (6 cases in total)
			        	else if ((indexmin==1 && indexmax==2)||(indexmin==2 && indexmax==1))
			        	{
			        		if (dice[2]>dice[3])
			        		{
			        		index2=3;
			        		index3=4;
			        		System.out.println("Player "+index2+" play second");
			        		System.out.println("Player "+index3+" play third");
			        		}
			        		else if (dice[2]<dice[3])
			        		{
			        		index2=4;
			        		index3=3;
			        		System.out.println("Player "+index2+" play second");
			        		System.out.println("Player "+index3+" play third");
			        		}
			        	}
			        	else if ((indexmin==1 && indexmax==3)||(indexmin==3 && indexmax==1))
			        	{
			        		if (dice[1]>dice[3])
			        		{
			        		index2=2;
			        		index3=4;
			        		System.out.println("Player "+index2+" play second");
			        		System.out.println("Player "+index3+" play third");
			        		}
			        		else if (dice[1]<dice[3])
			        		{
			        		index2=4;
			        		index3=2;
			        		System.out.println("Player "+index2+" play second");
			        		System.out.println("Player "+index3+" play third");
			        		}
			        	}
			        	else if ((indexmin==2 && indexmax==3)||(indexmin==3 && indexmax==2))
			        	{
			        		if (dice[0]>dice[3])
			        		{
			        		index2=1;
			        		index3=4;
			        		System.out.println("Player "+index2+" play second");
			        		System.out.println("Player "+index3+" play third");
			        		}
			        		else if (dice[0]<dice[3])
			        		{
			        		index2=4;
			        		index3=1;
			        		System.out.println("Player "+index2+" play second");
			        		System.out.println("Player "+index3+" play third");
			        		}
			        	}
			        	else if ((indexmin==2 && indexmax==4)||(indexmin==4 && indexmax==2))
			        	{
			        		if (dice[0]>dice[2])
			        		{
			        		index2=1;
			        		index3=3;
			        		System.out.println("Player "+index2+" play second");
			        		System.out.println("Player "+index3+" play third");
			        		}
			        		else if (dice[0]<dice[2])
			        		{
			        		index2=3;
			        		index3=1;
			        		System.out.println("Player "+index2+" play second");
			        		System.out.println("Player "+index3+" play third");
			        		}
			        	}
			        	else if ((indexmin==3 && indexmax==4)||(indexmin==4 && indexmax==3))
			        	{
			        		if (dice[0]>dice[1])
			        		{
			        		index2=1;
			        		index3=2;
			        		System.out.println("Player "+index2+" play second");
			        		System.out.println("Player "+index3+" play third");
			        		}
			        		else if (dice[1]<dice[0])
			        		{
			        		index2=2;
			        		index3=1;
			        		System.out.println("Player "+index2+" play second");
			        		System.out.println("Player "+index3+" play third");
			        		}
			        	}
			        	//print player order
			        	System.out.println("Player "+indexmin+" play last");
					    System.out.println("Reached final decision on order of playing: Player "+indexmax+", Player "+index2+", Player "+index3+", Player "+indexmin);
					    //4 snakeandladder object for 4 player
					    LadderAndSnake p1 = new LadderAndSnake(indexmax);
						LadderAndSnake p2 = new LadderAndSnake(index2);
						LadderAndSnake p3 = new LadderAndSnake(index3);
						LadderAndSnake p4 = new LadderAndSnake(indexmin);
					//status object to know if the game continue or is over
					Status game = new Status();				        
				    while (game.getStatus() == true)
				    {
				    	System.out.println("Please roll dice");
				    	//play()method for each player
				    	p1.play(game);
				        p2.play(game);
				        p3.play(game);
				        p4.play(game);				        
				     }
				    break;
			       }
				}
			}			
		}
			keyboard.close();
	   }
	}