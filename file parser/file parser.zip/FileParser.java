package a4part1;


/**Assignment 4 COMP249-PP Winter 2020
 * Xu Zhou Hu 40167460
 * This program is mainly about arraylist and file I/O.
 * It reads a file and give information on distinct words, words
 * starting with O and more than 3 vowels.
 * @author xuzho
 *
 */
import java.util.ArrayList;
import java.util.Scanner;
import java.io.PrintWriter;
import java.io.FileOutputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

public class FileParser {
	// attribute, path of input file, default and parameterized constructor
	public String path;

	public FileParser() {
		path = null;
	}

	public FileParser(String file) {
		path = file;
	}

	/**
	 * the method counting the number of vowels
	 * 
	 * @param s the string or word being counted
	 * @return
	 */
	public int nbvowel(String s) {
		char c;
		int count = 0;

		for (int i = 0; i < s.length(); i++) {
			c = s.charAt(i);
			if (c == 'a' || c == 'e' || c == 'i' || c == 'o' || c == 'u' || c == 'A' || c == 'E' || c == 'I' || c == 'O'
					|| c == 'U')
				count++;
		}
		return count;
	}

	/**
	 * main method, implement 3 arraylists recording 3 different data
	 */
	public void parse() {
		try {
			// 3 arraylists
			Scanner sc = new Scanner(new FileInputStream(path));
			ArrayList<String> vowel = new ArrayList<String>();
			ArrayList<String> o = new ArrayList<String>();
			ArrayList<String> distinct = new ArrayList<String>();
			String str;
			// continue reading if has next line
			while (sc.hasNext()) {
				str = sc.next();
				// remove all non alphanumeric characters
				str = str.replaceAll("[^a-zA-Z0-9]", "");
				// words from the input file which have more than three vowels
				if (nbvowel(str) > 3)
					vowel.add(str);
				// which start with 'O' or 'o'
				if (str.startsWith("o") || str.startsWith("O"))
					o.add(str);

				// distinct words
				if (!distinct.contains(str))
					distinct.add(str);
			}

			// 3 output files
			PrintWriter p1 = new PrintWriter(new FileOutputStream("D://vowel_verbiage.txt"));
			p1.println("Word Count: " + vowel.size());
			for (String s : vowel)
				p1.println(s);
			p1.close();

			PrintWriter p2 = new PrintWriter(new FileOutputStream("D://obsessive_o.txt"));
			p2.println("Word Count: " + o.size());
			for (String s : o)
				p2.println(s);
			p2.close();

			PrintWriter p3 = new PrintWriter(new FileOutputStream("D://distinct_data.txt"));
			p3.println("Word Count: " + distinct.size());
			for (String s : distinct)
				p3.println(s);
			p3.close();
			System.out.println("done, output files are in D drive");

		}
		// can't input/output
		catch (IOException e) {
			System.out.println("an error has occured");
		}
	}

	/**
	 * Main method, prompt user to enter path of the file they wish to convert
	 * 
	 * @param args
	 * @throws IOException
	 * @throws FileNotFoundException
	 */
	public static void main(String[] args) throws IOException, FileNotFoundException {
		Scanner kb = new Scanner(System.in);
		String file;
		System.out.print("which file to parse (please enter the path): ");
		file = kb.nextLine();
		try {
			Scanner sc = new Scanner(new FileInputStream(file));
		}
		// can't find file, maybe the path is wrong
		catch (FileNotFoundException e) {
			System.out.print("file cannot be found; ");
		}
		// create object and running method
		FileParser fp = new FileParser(file);
		fp.parse();
		kb.close();
	}

}