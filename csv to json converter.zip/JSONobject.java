package assignment3;

/**
 * Assignment 3 COMP249-PP Winter 2020 CSVtoJSON Xu Zhou Hu 40167460 This
 * program converts .csv files to .json files. This assignment is mainly about
 * Exception Handling and File Input/Output.
 * 
 * @author xuzho
 *
 */
public class JSONobject 
{
	String[] splitString;
	public JSONobject() {}
	public JSONobject(String row) {
		splitString = JSONformatting(row.split(","));
	}
	/**
	 * JSONformatting() method
	 * �.json� file is composed of an array of JSON objects, each line of 
	 * data in the CSV file is represented as a JSON object in the array.
	 * @param CSVarray row of .csv file stored in array
	 * @return
	 */
	public String[] JSONformatting(String[] CSVarray) {		
		int numberTokens = 0;
		String combineTokens;						
		int iterateString = 0;
		//The compiler breaks lines into pieces of text known as Java tokens.
		//loop to count number of tokens
		for (int i = 0; i < CSVarray.length; i++) 
		{
			if (CSVarray[i] != "") 
			{
				if (CSVarray[i].charAt(0) == '\"') 
				{
					for (int j = i + 1; j < CSVarray.length; j++) 
					{
						if (CSVarray[j].charAt(CSVarray[j].length() - 1) == '\"') 
						{
							numberTokens++;
							break;
						} else 
						{
							numberTokens++;
						}
					}
				}
			}
		}
		String[] JSONarray = new String[CSVarray.length - numberTokens];
		//combine tokens and loop to store JSONarray by iterating string
		for (int i = 0; i < CSVarray.length; i++) 
		{
			if (CSVarray[i] != "") 
			{
				if (CSVarray[i].charAt(0) == '\"') 
				{
					combineTokens = CSVarray[i].substring(1);
					for (int j = i + 1; j < CSVarray.length; j++) 
					{
						if (CSVarray[j].charAt(CSVarray[j].length() - 1) == '\"')
						{
							combineTokens = combineTokens + "," + CSVarray[j].substring(0, CSVarray[j].length() - 1);
							i = j;
							break;
						} 
						else 
						{
							combineTokens = combineTokens + "," + CSVarray[j];
						}
					}
					JSONarray[iterateString] = combineTokens;
				} 
				else 
				{
					JSONarray[iterateString] = CSVarray[i];
				}
			}
			iterateString++;
		}
		return JSONarray;
	}
}