package assignment3;
/**Assignment 3 COMP249-PP Winter 2020 CSVtoJSON
 * Xu Zhou Hu 40167460
 * This program converts .csv files to .json files. This assignment 
 * is mainly about Exception Handling and File Input/Output.
 * @author xuzho
 *
 */
//Define a new exception class that is triggered if either an attribute or a value is missing
public class CSVDataMissingException extends Exception {
	/**
	 * Constructor displaying a message if either an attribute or a value is missing
	 */
	public CSVDataMissingException() {
		super("");
	}
	/**
	 * @param s A constructor that takes a String parameter
	 * Allows the possibility to display any other desired exception message
	 */
	public CSVDataMissingException(String s) {
		super(s);
	}
	public String getMessage()
	{
		return super.getMessage();
	}
}