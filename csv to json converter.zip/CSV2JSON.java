package assignment3;

/**Assignment 3 COMP249-PP Winter 2020 CSVtoJSON
 * Xu Zhou Hu 40167460
 * This program converts .csv files to .json files. This assignment 
 * is mainly about Exception Handling and File Input/Output.
 * @author xuzho
 *
 */
import java.util.Scanner;
import java.io.PrintWriter;
import java.io.FileOutputStream;
import java.io.FileNotFoundException;
import java.io.FileInputStream;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class CSV2JSON 
{		
	/**
	 * generateJSONFile() method
	 * This method describes what information should the .json file contain and the mechanism behind it
	 * @param attribute first row information in .csv file
	 * @param value the rest of information in .csv file
	 * @param pwJSON printwriter for .json file
	 */
	public static void generateJSONFile(JSONobject attribute, JSONobject value, PrintWriter pwJSON)
	{
		pwJSON.println(" {");
		//for Car Maintenance record.csv, which has 9 attributes
		if (attribute.splitString.length == 9) 
		{
			for (int i = 0; i < 6; i++)
			{
				pwJSON.println(" \"" + attribute.splitString[i] + "\": \"" + value.splitString[i] + "\",");
			}
			for (int i = 6; i < 8; i++)
			{
				pwJSON.println(" \"" + attribute.splitString[i] + "\": " + value.splitString[i] + ",");
			}
			for (int i = 8; i < attribute.splitString.length; i++)
			{
				pwJSON.println(" \"" + attribute.splitString[i] + "\": " + value.splitString[i]);
			}
			pwJSON.println(" },");
		} 
		//for Car Rental record.csv, which has 8 attributes
		else 
		{
			for (int i = 0; i < 2; i++)
			{
				pwJSON.println(" \"" + attribute.splitString[i] + "\": \"" + value.splitString[i] + "\",");
			}
			for (int i = 2; i < 3; i++)
			{
				pwJSON.println(" \"" + attribute.splitString[i] + "\": " + value.splitString[i] + ",");
			}
			for (int i = 3; i < 5; i++)
			{
				pwJSON.println(" \"" + attribute.splitString[i] + "\": \"" + value.splitString[i] + "\",");
			}
			for (int i = 5; i < 7; i++)
			{
				pwJSON.println(" \"" + attribute.splitString[i] + "\": " + value.splitString[i] + ",");
			}
			for (int i = 7; i < attribute.splitString.length; i++)
			{
				pwJSON.println(" \"" + attribute.splitString[i] + "\": " + value.splitString[i]);
			}
			pwJSON.println(" },");
		}
	}
	/**
	 * this is the core engine, method processFilesForValidation()
	 * The purpose of this method is to check if attributes or values are missing or if all is good
	 * in case something is missing the company will be notified and a log file will also be generated
	 * @param scCSV       scanner for .csv files
	 * @param pwJSON      printwriter for .json files
	 * @param pwLogFile   printwriter for log files
	 * @param CSVpathName path name of csv file
	 */
	public static void processFilesForValidation(Scanner scCSV, PrintWriter pwJSON, PrintWriter pwLogFile, String CSVpathName) 
	{
		String row = scCSV.nextLine();
		JSONobject attribute = new JSONobject(row);
		JSONobject value = null;
		int MissingAttribute = 0;
		int MissingValue = 0;
		int LineOfMissingValue = 0;
		try 
		{
			//check if attributes are missing
			for (int i = 0; i < attribute.splitString.length; i++)
				if (attribute.splitString[i] == null)
					MissingAttribute++;
			//attribute missing, throw CSVFileInvalidException
			if (MissingAttribute > 0) 
			{
				throw new CSVFileInvalidException();
			} 
			else 
			{
				pwJSON.println("[");

				while (scCSV.hasNextLine()) 
				{
					value = new JSONobject(scCSV.nextLine());
					try 
					{
						for (int i = 0; i < value.splitString.length; i++)
						{
							//check if values are missing
							if (value.splitString[i] == null)
							{
								MissingValue++;
								LineOfMissingValue = i;
							}
						}
						//value missing, throw CSVDataMissingException
						if (MissingValue > 0)
							throw new CSVDataMissingException();
						//if everything is correct, trigger method generateJSON file to generate .json file
						else
							generateJSONFile(attribute, value, pwJSON);
					} 
					catch (CSVDataMissingException e) 
					{
						//a message will be displayed to the user in case of missing value
						System.out.println("In file " + CSVpathName + " line " + LineOfMissingValue
								+ " not converted to JSON: missing data.");
						//the log file will be generated in case of missing value with the method generateLogFile()
						generateLogFile(attribute, value, pwLogFile, CSVpathName, LineOfMissingValue, 2);
						MissingValue = 0;
					}
				}
				pwJSON.println("]");
			}
		} 
		catch (CSVFileInvalidException e) 
		{
			//a message will be displayed to the user in case of missing attribute
			System.out.println("File " + CSVpathName + " is invalid: field is missing.");
			System.out.println("File is not converted to JSON.");
			//the log file will be generated in case of missing attribute with the method generateLogFile()
			generateLogFile(attribute, value, pwLogFile, CSVpathName, MissingAttribute, 1);
		}
	}
	/**
	 * generateLogFile() method
	 * this method describes what information should the log file contain and the mechanism behind it
	 * @param attribute information in the 1st row in .csv files
	 * @param value the rest of information in .csv files
	 * @param pwLogFile printwriter for log files
	 * @param CSVpathName path name of .csv file
	 * @param nbFieldOrLineOfValue nb of field of missing attribute or line of missing value
	 * @param missingFieldOrValue ==1 if field missing, else if attribute missing
	 */
	public static void generateLogFile(JSONobject attribute, JSONobject value, PrintWriter pwLogFile, String CSVpathName, int nbFieldOrLineOfValue, int missingFieldOrValue) {
		//field missing
		if (missingFieldOrValue == 1) 
		{
			//log file if field missing
			pwLogFile.println("File " + CSVpathName + " is invalid");
			pwLogFile.println("Missing Field: " + (attribute.splitString.length - nbFieldOrLineOfValue) + " detected, "
					+ nbFieldOrLineOfValue + " missing");
			//display attributes and the missing field in the form of "***"
			for (int i = 0; i < attribute.splitString.length - 1; i++) 
			{
				if (attribute.splitString[i] != null)
					pwLogFile.print(attribute.splitString[i] + ", ");
				else
					pwLogFile.print("***, ");
			}
			if (attribute.splitString[attribute.splitString.length - 1] != null)
				pwLogFile.println(attribute.splitString[attribute.splitString.length - 1]);
			else
				pwLogFile.println("***");

			System.out.println();
		} 
		//log file if value is missing
		else 
		{			
			int lineOfValue = 0;
			//display line nb of missing value
			pwLogFile.println("In file " + CSVpathName + " line " + nbFieldOrLineOfValue);
			//display the whole row of values with in missing value in the form of ***
			for (int i = 0; i < value.splitString.length; i++) 
			{
				if (value.splitString[i] == null)
				{
					pwLogFile.print("*** ");
					lineOfValue = i;
				} 
				else
					pwLogFile.print(value.splitString[i] + " ");
			}
			//display which attribute is the missing value under
			pwLogFile.println();
			pwLogFile.println("Missing: " + attribute.splitString[lineOfValue]);
		}
		pwLogFile.println("------------------------");
	}	
	/**
	 * displayFiles() method
	 * This method will prompt user to enter the path name of .json file they want to display.
	 * They have 2 chance to enter a correct path name or program terminates.
	 * Finally, they can open multiple .json files if they wish.
	 */
	public static void displayFiles() 
	{
		String JSONpathName;
		String displayRow;
		int nbOfChanceRemaining = 1;
		BufferedReader BufferedReader = new BufferedReader(new InputStreamReader(System.in));
		BufferedReader brJSON;
		//2 chance to enter a correct path name
		while (nbOfChanceRemaining == 1)
		{
			try 
			{
				System.out.print("Please enter the full path name of .json file to be displayed: ");
				//read user input
				JSONpathName = BufferedReader.readLine();
				System.out.println();
				try
				{
					//new .json file
					brJSON = new BufferedReader((new FileReader(JSONpathName)));
				} 
				//if the user didn't enter a correct path name, give user final chance
				catch (FileNotFoundException e) 
				{
					System.out.print("The user is allowed a final chance to enter a correct .json file path name: ");
					JSONpathName = BufferedReader.readLine();
					brJSON = new BufferedReader((new FileReader(JSONpathName)));
					System.out.println();
				}
				displayRow = brJSON.readLine();
				//read every row if there is still a row
				while (displayRow != null)
				{
					System.out.println(displayRow);
					displayRow = brJSON.readLine();
				}
				//the user can open multiple .json files if they wish
				System.out.println("The .json file has been displayed.");
				System.out.print("Want to display another .json file? Enter 1 to add another chance: ");
				nbOfChanceRemaining = Integer.parseInt(BufferedReader.readLine());
			} 
			//if the user didn't enter a correct path name 2 times in a row, terminate program
			catch (FileNotFoundException e) 
			{
				System.out.println("The user has exhuasted the granted 2 chances to enter a correct path name.");
				System.out.print("Program termminates.");
				nbOfChanceRemaining = 0;
			}
			//if the user doesn't want to display another .json file
			catch (Exception e) 
			{
				System.out.println("Looks like you don't want to display another .json file.");
				System.out.print("Program termminates. Have a nice day!");
				nbOfChanceRemaining = 0;
			}
		}
	}
	/**
	 * Main method
	 * The purpose of the main() method is to link .csv, .json and log file with methods
	 * @param args
	 * @throws IOException
	 * @throws CSVFileInvalidException
	 */
	public static void main(String[] args) throws IOException, CSVFileInvalidException {
		System.out.println("CSV to JSON converter");
		System.out.println("---------------------");
		System.out.println("How many CSV files to convert? Enter an integer number: ");
		Scanner keyboard = new Scanner(System.in);
		int nbCSVfiles;
		// user input nb of .csv file to convert
		nbCSVfiles = Integer.parseInt(keyboard.nextLine());
		String[] CSVpathName = new String[nbCSVfiles];
		Scanner[] scCSV = new Scanner[nbCSVfiles];
		PrintWriter[] pwJSON = new PrintWriter[nbCSVfiles];
		// loop for nb of .csv files
		for (int i = 0; i < nbCSVfiles; i++) 
		{
			System.out.print("What is the full path name of CSV file number " + (i + 1) + " to convert: ");
			// user input path name .csv file
			CSVpathName[i] = keyboard.nextLine();
			try 
			{
				// new .csv file
				scCSV[i] = new Scanner(new FileInputStream(CSVpathName[i]));
			}
			// if the user enters a wrong path name of .csv file
			catch (FileNotFoundException e)
			{
				System.out.println("Could not open a .csv file " + CSVpathName[i] + " for reading.");
				System.out.println("Please check if file exists! Program will terminate after closing all open files.");
				// close all opened files
				for (int j = i - 1; j >= 0; j--) 
				{
					scCSV[j].close();
				}
				System.exit(0);
			}
		}
		// loop for nb of .json files
		for (int i = 0; i < nbCSVfiles; i++) 
		{
			// take out "csv" and replace by "json" to get the path name of .json file
			String JSONpath = CSVpathName[i].substring(0, CSVpathName[i].length() - 3) + "json";
			try 
			{
				// new .json file
				pwJSON[i] = new PrintWriter(new FileOutputStream(JSONpath));
			}
			// .json file can't be created due to permission or no memory
			catch (FileNotFoundException e)
			{
				System.out.println("Could not create a .json file " + JSONpath + " to write to. "
						+ " Please check for problems such as directory permission" + " or no available memory.");
				System.out.println("Program will terminate after closing all open files.");
				for (int j = i - 1; j >= 0; j--)
				{
					// in case of FileNotFoundException, close all opened .json files
					pwJSON[j].close();
				}
				for (int k = nbCSVfiles - 1; k >= 0; k--)
				{
					// in case of FileNotFoundException, close all opened .csv files
					scCSV[k].close();
				}
				System.exit(0);
			}
		}
		for (int i = 0; i < nbCSVfiles; i++)
		{
			// appending output to log file
			PrintWriter pwLogFile = new PrintWriter(new FileOutputStream("D:\\LogFile.txt", true));
			// initiating core engine
			processFilesForValidation(scCSV[i], pwJSON[i], pwLogFile, CSVpathName[i]);
			System.out.println("Initiating core engine processFilesForValidation() " + CSVpathName[i]);
			System.out.println("---------------------");
			// close scanners and printwriters once done
			scCSV[i].close();
			pwJSON[i].close();
			pwLogFile.close();
		}
		// show output
		displayFiles();
		keyboard.close();
	}
}
