package assignment3;
/**Assignment 3 COMP249-PP Winter 2020 CSVtoJSON
 * Xu Zhou Hu 40167460
 * This program converts .csv files to .json files. This assignment 
 * is mainly about Exception Handling and File Input/Output.
 * @author xuzho
 *
 */
//Define a new exception class that is triggered if the path name of .csv file entered is not correct
public class CSVFileInvalidException extends Exception {
	/**
	 * Constructor displaying a message if the path name of .csv file entered is not correct
	 */
	public CSVFileInvalidException() {
		super("");
	}
	/**
	 * @param s A constructor that takes a String parameter
	 * Allows the possibility to display any other desired exception message
	 */
	public CSVFileInvalidException(String s) {
		super(s);
	}
	public String getMessage()
	{
		return super.getMessage();
	}
}
