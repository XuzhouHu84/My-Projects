/*
 Xu Zhou Hu 40167460
 COMP 249 - Assignment #1 - Address
 Due Date: 8 March 2021
 */
package p3;

import p1.Address;
/**
 * @author xuzho
 *class geographic address is a derived class from address, list parameters
 */
public class GeographicAddress extends Address {
	
	private String address;
	private String city;
	private String region;
	private String zipcode;
	private String locale;

	
	/**
	 * default constructor
	 */
	
	public GeographicAddress() {
		super();
		address = "777 Sesame Street";
		city = "Longueil";
		region = "Quebec";
		zipcode = "W8B 0E4";
		locale = "CA 124 Canada";

		System.out.println("Creating a geographic address object using default constructor ...");
	}

	/**
	 * parameterized constructor
	 * @param address
	 * @param city
	 * @param locale
	 * @param region
	 * @param zipcode
	 * @param validTo
	 * @param validFrom
	 */
	
	
	public GeographicAddress(String address, String city, String locale, String region, String zipcode, String validTo,
			String validFrom) {
		super(validFrom, validTo);
		this.address = address;
		this.city = city;
		this.region = region;
		this.zipcode = zipcode;
		this.locale = locale;

		System.out.println("Creating a geographic address object using parameterzed constructor ...");
	}	
	/**
	 * copy constructor
	 */	
	public GeographicAddress(GeographicAddress geoadd) {
		super(new Address(geoadd.getValidFrom(), geoadd.getValidTo()));
		this.address = geoadd.address;
		this.city = geoadd.city;
		this.region = geoadd.region;
		this.zipcode = geoadd.zipcode;
		this.locale = geoadd.locale;
		System.out.println("Creating a geographic address object using copy constructor ...");
	}
	/**
	 * get() and set() methods
	 */
	public String getaddress() {
		return address;
	}

	public void setaddress(String address) {
		this.address = address;
	}

	public String getcity() {
		return city;
	}

	public void setcity(String city) {
		this.city = city;
	}

	public String getregion() {
		return region;
	}

	public void setregion(String region) {
		this.region = region;
	}

	public String getzipcode() {
		return zipcode;
	}

	public void setzipcode(String zipcode) {
		this.zipcode = zipcode;
	}

	public String getlocale() {
		return locale;
	}

	public void setlocale(String locale) {
		this.locale = locale;
	}
	/**
	 * toString() override method
	 * equals() override method
	 */
	
	@Override
	public String toString() {

		String[] from = getValidFrom().split("-");
		String[] to = getValidTo().split("-");
		int year = java.time.LocalDate.now().getYear();
		int month = java.time.LocalDate.now().getMonthValue();
		int day = java.time.LocalDate.now().getDayOfMonth();
		String valid = " and therefore ";
		if (Integer.valueOf(to[0]) < year || Integer.valueOf(from[0]) > year)
			valid += "obsolete!!!";
		else if (Integer.valueOf(from[0]) < year && Integer.valueOf(to[0]) > year) {
			valid += "still usable today ...";
		} else {
			if (Integer.valueOf(from[0]) <= year && Integer.valueOf(to[0]) == year) {
				if (Integer.valueOf(to[1]) < month || Integer.valueOf(from[1]) > month)
					valid += "obsolete!!!";
				else if (Integer.valueOf(to[1]) > month) {
					valid += "still usable today ...";
				} else {
					if (Integer.valueOf(from[1]) <= month && Integer.valueOf(to[1]) == month) {
						if (Integer.valueOf(to[2]) < day || Integer.valueOf(from[2]) > day)
							valid += "obsolete!!!";
						else if (Integer.valueOf(to[1]) >= day) {
							valid += "still usable today ...";
						}
					} else if (Integer.valueOf(from[1]) <= month && Integer.valueOf(to[1]) > month) {
						if (Integer.valueOf(from[2]) > day)
							valid += "obsolete!!!";
						else
							valid += "still usable today ...";
					} else {
						valid += "obsolete!!!";
					}
				}
			} else if (Integer.valueOf(from[0]) <= year && Integer.valueOf(to[0]) > year) {
				if (Integer.valueOf(from[1]) > month)
					valid += "obsolete!!!";
				else
					valid += "still usable today ...";
			} else {
				valid += "obsolete!!!";
			}
		}
		return "Geographic address is " + address + ", " + city + ", " + region + ", " + zipcode + " and is valid from "
				+ getValidFrom() + " to " + getValidTo() + valid + "\n";
	}

	@SuppressWarnings("unused")
	public boolean equals(Address add) {
		String s1 = this.getClass().toString(), s2 = add.getClass().toString();
		if (add == null && add.getClass() == this.getClass()) {
			return false;
		} else {
			return true;
		}
	}

}
