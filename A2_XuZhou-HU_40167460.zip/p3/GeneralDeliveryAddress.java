/*
 Xu Zhou Hu 40167460
 COMP 249 - Assignment #1 - Address
 Due Date: 8 March 2021
 */
package p3;

import p1.Address;
/**
 * @author xuzho
 *class general delivery adressd is a derived class from address, list parameters
 */
public class GeneralDeliveryAddress extends Address {
	
	private String address;
	private String city;
	private String region;
	private String zipcode;
	private String country;
	private String natprefix;
	private int area;
	private long number;
	private int extension;
	private String physical;

	
	/**
	 * default constructor
	 */
	
	public GeneralDeliveryAddress() {
		super();
		address = "125 Meadow Street";
		city = "Montreal";
		region = "Quebec";
		zipcode = "H0H 0H0";
		country = "+1";
		natprefix = "(0)";
		area = 208;
		number = 1234567;
		extension = 789;
		physical = "mobile";
		System.out.println("Creating a general delivery address object using default constructor ...");
	}

	/**
	 * parameterized constructor
	 * @param country
	 * @param natprefix
	 * @param area
	 * @param number
	 * @param extension
	 * @param physical
	 * @param address
	 * @param city
	 * @param locale
	 * @param region
	 * @param zipcode
	 * @param validTo
	 * @param validFrom
	 * @param code
	 */
	
	
	public GeneralDeliveryAddress(String country, String natprefix, int area, long number, int extension,
			String physical, String address, String city, String locale, String region, String zipcode, String validTo,
			String validFrom, int code) {
		super(validFrom, validTo);
		this.address = address;
		this.city = city;
		this.region = region;
		this.zipcode = zipcode;
		this.country = country;
		this.natprefix = natprefix;
		this.area = area;
		this.number = number;
		this.extension = extension;
		this.physical = physical;
		System.out.println("Creating a general delivery address object using parameterzed constructor ...");
	}
	/**
	 * copy constructor
	 */
	public GeneralDeliveryAddress(GeneralDeliveryAddress PObox) {
		super(new Address(PObox.getValidFrom(), PObox.getValidTo()));
		this.address = PObox.address;
		this.city = PObox.city;
		this.region = PObox.region;
		this.zipcode = PObox.zipcode;
		this.country = PObox.country;
		this.natprefix = PObox.natprefix;
		this.area = PObox.area;
		this.number = PObox.number;
		this.extension = PObox.extension;
		this.physical = PObox.physical;

		System.out.println("Creating a general delivery address object using copy constructor ...");
	}
	/**
	 * get() and set() methods
	 */	
	public String getaddress() {
		return address;
	}

	public void setaddress(String address) {
		this.address = address;
	}

	public String getcity() {
		return city;
	}

	public void setcity(String city) {
		this.city = city;
	}

	public String getregion() {
		return region;
	}

	public void setregion(String region) {
		this.region = region;
	}

	public String getzipcode() {
		return zipcode;
	}

	public void setzipcode(String zipcode) {
		this.zipcode = zipcode;
	}

	public String getcountry() {
		return country;
	}

	public void setcountry(String country) {
		this.country = country;
	}

	public String getnatprefix() {
		return natprefix;
	}

	public void setnatprefix(String natprefix) {
		this.natprefix = natprefix;
	}

	public int getarea() {
		return area;
	}

	public void setarea(int area) {
		this.area = area;
	}

	public long getnumber() {
		return number;
	}

	public void setnumber(long number) {
		this.number = number;
	}

	public int getextension() {
		return extension;
	}

	public void setextension(int extension) {
		this.extension = extension;
	}

	public String getphysical() {
		return physical;
	}

	public void setphysical(String physical) {
		this.physical = physical;
	}

	/**
	 * toString() override method
	 * equals() override method
	 */
	@Override
	public String toString() {

		String[] from = getValidFrom().split("-");
		String[] to = getValidTo().split("-");
		int year = java.time.LocalDate.now().getYear();
		int month = java.time.LocalDate.now().getMonthValue();
		int day = java.time.LocalDate.now().getDayOfMonth();
		String valid = " and therefore ";
		if (Integer.valueOf(to[0]) < year || Integer.valueOf(from[0]) > year)
			valid += "obsolete!!!";
		else if (Integer.valueOf(from[0]) < year && Integer.valueOf(to[0]) > year) {
			valid += "still usable today ...";
		} else {
			if (Integer.valueOf(from[0]) <= year && Integer.valueOf(to[0]) == year) {
				if (Integer.valueOf(to[1]) < month || Integer.valueOf(from[1]) > month)
					valid += "obsolete!!!";
				else if (Integer.valueOf(to[1]) > month) {
					valid += "still usable today ...";
				} else {
					if (Integer.valueOf(from[1]) <= month && Integer.valueOf(to[1]) == month) {
						if (Integer.valueOf(to[2]) < day || Integer.valueOf(from[2]) > day)
							valid += "obsolete!!!";
						else if (Integer.valueOf(to[1]) >= day) {
							valid += "still usable today ...";
						}
					} else if (Integer.valueOf(from[1]) <= month && Integer.valueOf(to[1]) > month) {
						if (Integer.valueOf(from[2]) > day)
							valid += "obsolete!!!";
						else
							valid += "still usable today ...";
					} else {
						valid += "obsolete!!!";
					}
				}
			} else if (Integer.valueOf(from[0]) <= year && Integer.valueOf(to[0]) > year) {
				if (Integer.valueOf(from[1]) > month)
					valid += "obsolete!!!";
				else
					valid += "still usable today ...";
			} else {
				valid += "obsolete!!!";
			}
		}
		return "General Delivery address with telecom address " + country + " " + natprefix + area + " " + number
				+ " ext. " + extension + " is " + address + ", " + city + ", " + region + ", " + zipcode
				+ " and is valid from " + getValidFrom() + " to " + getValidTo() + valid + "\n";
	}

	@SuppressWarnings("unused")
	public boolean equals(Address add) {
		String s1 = this.getClass().toString(), s2 = add.getClass().toString();
		if (add == null && add.getClass() == this.getClass()) {
			return false;
		} else {
			return true;
		}
	}

}
