/*
 Xu Zhou Hu 40167460
 COMP 249 - Assignment #1 - Address
 Due Date: 8 March 2021
 */
package p1;
/**
 * @author xuzho
 *parent class, list parameters
 */
public class Address {

	private String validFrom;
	private String validTo;
	/**
	 * default constructor
	 */
	public Address() {
		validFrom = "2011-11-11";
		validTo = "2021-11-11";
		System.out.println("Creating an address object using default constructor ...");
	}
	/**
	 * parameterized constructor
	 * @param validFrom
	 * @param validTo
	 */

	public Address(String validFrom, String validTo) {
		this.validFrom = validFrom;
		this.validTo = validTo;
		System.out.println("Creating an address object using parameterized constructor ...");
	}
	/**
	 * copy constructor
	 */
	public Address(Address add) {
		this.validFrom = add.validFrom;
		this.validTo = add.validTo;
		System.out.println("Creating an address object using copy constructor ...");
	}
	/**
	 * get() and set() methods
	 */	
	public String getValidFrom() {
		return validFrom;
	}

	public void setValidFrom(String validFrom) {
		this.validFrom = validFrom;
	}

	public String getValidTo() {
		return validTo;
	}

	public void setValidTo(String validTo) {
		this.validTo = validTo;
	}

	public String toString() {
		return "Address valid from " + this.getValidFrom() + "to " + this.getValidTo();
	}
	/**
	 * toString() method
	 * equals() method
	 */
	@SuppressWarnings("unused")
	public boolean equals(Address add) {
		String s1 = this.getClass().toString(), s2 = add.getClass().toString();
		if (add == null && add.getClass() == this.getClass()) {
			return false;
		} else {
			return true;
		}
	}

}
