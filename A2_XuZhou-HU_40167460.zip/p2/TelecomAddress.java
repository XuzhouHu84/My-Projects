/*
 Xu Zhou Hu 40167460
 COMP 249 - Assignment #1 - Address
 Due Date: 8 March 2021
 */
package p2;

import p1.Address;
/**
 * @author xuzho
 *class telecome address address is a derived class from address, list parameters
 */
public class TelecomAddress extends Address {
	
	private String country;
	private String natprefix;
	private int area;
	private long number;
	private int extension;
	private String physical;

	
	/**
	 * default constructor
	 */
	
	public TelecomAddress() {
		super();
		country = "+1";
		natprefix = "(0)";
		area = 208;
		number = 1234567;
		extension = 789;
		physical = "mobile";
		System.out.println("Creating a telecom address object using default constructor ...");
	}
	/**
	 * parameterized constructor
	 * @param country
	 * @param natprefix
	 * @param area
	 * @param number
	 * @param extension
	 * @param physical
	 * @param validFrom
	 * @param validTo
	 */
	public TelecomAddress(String country, String natprefix, int area, long number, int extension, String physical,
			String validFrom, String validTo) {
		super(validFrom, validTo);
		this.country = country;
		this.natprefix = natprefix;
		this.area = area;
		this.number = number;
		this.extension = extension;
		this.physical = physical;
		System.out.println("Creating a telecom address object using parameterzed constructor ...");
	}
	/**
	 * copy constructor
	 */
	public TelecomAddress(TelecomAddress teleadd) {
		super(new Address(teleadd.getValidFrom(), teleadd.getValidTo()));
		this.country = teleadd.country;
		this.natprefix = teleadd.natprefix;
		this.area = teleadd.area;
		this.number = teleadd.number;
		this.extension = teleadd.extension;
		this.physical = teleadd.physical;
		System.out.println("Creating a telecom address object using copy constructor ...");
	}
	/**
	 * get() and set() methods
	 */	
	
	public String getcountry() {
		return country;
	}

	public void setcountry(String country) {
		this.country = country;
	}

	public String getnatprefix() {
		return natprefix;
	}

	public void setnatprefix(String natprefix) {
		this.natprefix = natprefix;
	}

	public int getarea() {
		return area;
	}

	public void setarea(int area) {
		this.area = area;
	}

	public long getnumber() {
		return number;
	}

	public void setnumber(long number) {
		this.number = number;
	}

	public int getextension() {
		return extension;
	}

	public void setextension(int extension) {
		this.extension = extension;
	}

	public String getphysical() {
		return physical;
	}

	public void setphysical(String physical) {
		this.physical = physical;
	}
	/**
	 * toString() override method
	 * equals() override method
	 */
	
	@Override
	public String toString() {

		String[] from = getValidFrom().split("-");
		String[] to = getValidTo().split("-");
		int year = java.time.LocalDate.now().getYear();
		int month = java.time.LocalDate.now().getMonthValue();
		int day = java.time.LocalDate.now().getDayOfMonth();
		String valid = " and therefore ";
		if (Integer.valueOf(to[0]) < year || Integer.valueOf(from[0]) > year)
			valid += "obsolete!!!";
		else if (Integer.valueOf(from[0]) < year && Integer.valueOf(to[0]) > year) {
			valid += "still usable today ...";
		} else {
			if (Integer.valueOf(from[0]) <= year && Integer.valueOf(to[0]) == year) {
				if (Integer.valueOf(to[1]) < month || Integer.valueOf(from[1]) > month)
					valid += "obsolete!!!";
				else if (Integer.valueOf(to[1]) > month) {
					valid += "still usable today ...";
				} else {
					if (Integer.valueOf(from[1]) <= month && Integer.valueOf(to[1]) == month) {
						if (Integer.valueOf(to[2]) < day || Integer.valueOf(from[2]) > day)
							valid += "obsolete!!!";
						else if (Integer.valueOf(to[1]) >= day) {
							valid += "still usable today ...";
						}
					} else if (Integer.valueOf(from[1]) <= month && Integer.valueOf(to[1]) > month) {
						if (Integer.valueOf(from[2]) > day)
							valid += "obsolete!!!";
						else
							valid += "still usable today ...";
					} else {
						valid += "obsolete!!!";
					}
				}
			} else if (Integer.valueOf(from[0]) <= year && Integer.valueOf(to[0]) > year) {
				if (Integer.valueOf(from[1]) > month)
					valid += "obsolete!!!";
				else
					valid += "still usable today ...";
			} else {
				valid += "obsolete!!!";
			}
		}
		return "Telecom address is " + country + " " + natprefix + area + " " + number + " ext. " + extension
				+ ", it's type is " + physical + " and is valid from " + getValidFrom() + " to " + getValidTo() + valid
				+ "\n";
	}

	@SuppressWarnings("unused")
	public boolean equals(Address add) {
		String s1 = this.getClass().toString(), s2 = add.getClass().toString();
		if (add == null && add.getClass() == this.getClass()) {
			return false;
		} else {
			return true;
		}
	}
}