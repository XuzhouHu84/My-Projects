/*
 Xu Zhou Hu 40167460
 COMP 249 - Assignment #1 - Address
 Due Date: 8 March 2021
 */
package p2;

import p1.Address;
/**
 * @author xuzho
 *class webpage address is a derived class from address, list parameters
 */
public class WebPageAddress extends Address {
	
	private String url;

	/**
	 * default constructor
	 */
	public WebPageAddress() {
		super();
		url = "www.wikipedia.ca";
		System.out.println("Creating a webpage address object using default constructor ...");
	}

	/**
	 * parameterized constructor
	 * @param url
	 * @param validFrom
	 * @param validTo
	 */
	public WebPageAddress(String url, String validFrom, String validTo) {
		super(validFrom, validTo);
		seturl(url);
		System.out.println("Creating a webpage address object using parameterized constructor ...");
	}
	/**
	 * copy constructor
	 */
	public WebPageAddress(WebPageAddress webAddress) {
		super(new Address(webAddress.getValidFrom(), webAddress.getValidTo()));
		this.url = webAddress.url;
		System.out.println("Creating a webpage address object using copy constructor ...");
	}
	/**
	 * get() and set() methods
	 */	
	
	public String geturl() {
		return url;
	}

	public void seturl(String url) {
		this.url = url;
	}
	/**
	 * toString() override method
	 * equals() override method
	 */
	
	@Override
	
	public String toString() {
		String[] from = getValidFrom().split("-");
		String[] to = getValidTo().split("-");
		int year = java.time.LocalDate.now().getYear();
		int month = java.time.LocalDate.now().getMonthValue();
		int day = java.time.LocalDate.now().getDayOfMonth();
		String valid = " and therefore ";
		if (Integer.valueOf(to[0]) < year || Integer.valueOf(from[0]) > year)
			valid += "obsolete!!!";
		else if (Integer.valueOf(from[0]) < year && Integer.valueOf(to[0]) > year) {
			valid += "still usable today ...";
		} else {
			if (Integer.valueOf(from[0]) <= year && Integer.valueOf(to[0]) == year) {
				if (Integer.valueOf(to[1]) < month || Integer.valueOf(from[1]) > month)
					valid += "obsolete!!!";
				else if (Integer.valueOf(to[1]) > month) {
					valid += "still usable today ...";
				} else {
					if (Integer.valueOf(from[1]) <= month && Integer.valueOf(to[1]) == month) {
						if (Integer.valueOf(to[2]) < day || Integer.valueOf(from[2]) > day)
							valid += "obsolete!!!";
						else if (Integer.valueOf(to[1]) >= day) {
							valid += "still usable today ...";
						}
					} else if (Integer.valueOf(from[1]) <= month && Integer.valueOf(to[1]) > month) {
						if (Integer.valueOf(from[2]) > day)
							valid += "obsolete!!!";
						else
							valid += "still usable today ...";
					} else {
						valid += "obsolete!!!";
					}
				}
			} else if (Integer.valueOf(from[0]) <= year && Integer.valueOf(to[0]) > year) {
				if (Integer.valueOf(from[1]) > month)
					valid += "obsolete!!!";
				else
					valid += "still usable today ...";
			} else {
				valid += "obsolete!!!";
			}
		}
		return "Webpage address " + url + " is valid from " + getValidFrom() + " to " + getValidTo() + valid + "\n";
	}

	@SuppressWarnings("unused")
	public boolean equals(Address add) {
		String s1 = this.getClass().toString(), s2 = add.getClass().toString();
		if (add == null && add.getClass() == this.getClass()) {
			return false;
		} else {
			return true;
		}
	}

}
