/*
 Xu Zhou Hu 40167460
 COMP 249 - Assignment #1 - Address
 Due Date: 8 March 2021
 */
package p2;

import p1.Address;
/**
 * @author xuzho
 *class email address is a derived class from address, list parameters
 */
public class EmailAddress extends Address {
	
	private String username;
	private String at;
	private String domainname;
	private String dot;
	private String tld;

	/**
	 * default constructor
	 */
	
	
	public EmailAddress() {
		super();
		username = "apple";
		at = "@";
		domainname = "yahoo";
		dot = ".";
		tld = "com";
		System.out.println("Creating an email address object using default constructor ...");
	}

	/**
	 * parameterized constructor
	 * @param username
	 * @param at
	 * @param domainname
	 * @param dot
	 * @param tld
	 * @param validFrom
	 * @param validTo
	 */
	
	
	public EmailAddress(String username, String at, String domainname, String dot, String tld, String validFrom,
			String validTo) {
		super(validFrom, validTo);
		this.username = username;
		this.at = at;
		this.domainname = domainname;
		this.dot = dot;
		this.tld = tld;
		System.out.println("Creating an email address object using parameterzed constructor ...");
	}
	/**
	 * copy constructor
	 */
	public EmailAddress(EmailAddress email) {
		super(email);
		this.username = email.username;
		this.at = email.at;
		this.domainname = email.domainname;
		this.dot = email.dot;
		this.tld = email.tld;
		System.out.println("Creating an email address object using copy constructor ...");
	}
	/**
	 * get() and set() methods
	 */	
	
	public String getusername() {
		return username;
	}

	public void setusername(String username) {
		this.username = username;
	}

	public String getat() {
		return at;
	}

	public void setat(String at) {
		this.at = at;
	}

	public String getdomainname() {
		return domainname;
	}

	public void setdomainname(String domainname) {
		this.domainname = domainname;
	}

	public String getdot() {
		return dot;
	}

	public void setdot(String dot) {
		this.dot = dot;
	}

	public String gettld() {
		return tld;
	}

	public void settld(String tld) {
		this.tld = tld;
	}
	/**
	 * toString() override method
	 * equals() override method
	 */
	public String toString() {
		String[] from = getValidFrom().split("-");
		String[] to = getValidTo().split("-");
		int year = java.time.LocalDate.now().getYear();
		int month = java.time.LocalDate.now().getMonthValue();
		int day = java.time.LocalDate.now().getDayOfMonth();
		String valid = " and therefore ";
		if (Integer.valueOf(to[0]) < year || Integer.valueOf(from[0]) > year)
			valid += "obsolete!!!";
		else if (Integer.valueOf(from[0]) < year && Integer.valueOf(to[0]) > year) {
			valid += "still usable today ...";
		} else {
			if (Integer.valueOf(from[0]) <= year && Integer.valueOf(to[0]) == year) {
				if (Integer.valueOf(to[1]) < month || Integer.valueOf(from[1]) > month)
					valid += "obsolete!!!";
				else if (Integer.valueOf(to[1]) > month) {
					valid += "still usable today ...";
				} else {
					if (Integer.valueOf(from[1]) <= month && Integer.valueOf(to[1]) == month) {
						if (Integer.valueOf(to[2]) < day || Integer.valueOf(from[2]) > day)
							valid += "obsolete!!!";
						else if (Integer.valueOf(to[1]) >= day) {
							valid += "still usable today ...";
						}
					} else if (Integer.valueOf(from[1]) <= month && Integer.valueOf(to[1]) > month) {
						if (Integer.valueOf(from[2]) > day)
							valid += "obsolete!!!";
						else
							valid += "still usable today ...";
					} else {
						valid += "obsolete!!!";
					}
				}
			} else if (Integer.valueOf(from[0]) <= year && Integer.valueOf(to[0]) > year) {
				if (Integer.valueOf(from[1]) > month)
					valid += "obsolete!!!";
				else
					valid += "still usable today ...";
			} else {
				valid += "obsolete!!!";
			}
		}
		return "Email address " + username + at + domainname + dot + tld + " is valid from " + getValidFrom() + " to "
				+ getValidTo() + valid + "\n";
	}

	@SuppressWarnings("unused")
	public boolean equals(Address add) {
		String s1 = this.getClass().toString(), s2 = add.getClass().toString();
		if (add == null && add.getClass() == this.getClass()) {
			return false;
		} else {
			return true;
		}
	}

}
