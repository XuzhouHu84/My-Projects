/*
 Xu Zhou Hu 40167460
 COMP 249 - Assignment #1 - Address
 Due Date: 8 March 2021
 */
package p2;
import p1.*;
import p3.*;

public class driver {

	public static void main(String[] args) {
		//create array 15 objects
		Address[] add = new Address[15];
		//15 objects
		EmailAddress add1 = new EmailAddress("john", "@", "gmail", ".", "com", "2010-01-01", "2030-01-01");
		WebPageAddress add2 = new WebPageAddress("www.google.com/wiki", "2010-01-01", "2020-01-01");
		//TEST PARAMETERIZED CONSTRUCTOR
		EmailAddress add3 = new EmailAddress("jack", "@", "hotmail", ".", "com", "2010-01-01", "2030-01-01");
		//TEST COPY CONSTRUCTOR
		WebPageAddress add4 = new WebPageAddress(add2);
		//TEST DEFAULT CONSTRUCTOR
		EmailAddress add5 = new EmailAddress();
		TelecomAddress add6 = new TelecomAddress();
		GeneralDeliveryAddress add7 = new GeneralDeliveryAddress();
		GeographicAddress add8 = new GeographicAddress();
		PostOfficeBoxAddress add9 = new PostOfficeBoxAddress();
		TelecomAddress add10 = new TelecomAddress("+1", "(0)", 999, 999999999, 666, "fax", "2017-12-11", "2022-12-11");
		WebPageAddress add11 = new WebPageAddress("www.facebook.com/zuckerberg", "2016-06-23", "2023-07-01");
		GeneralDeliveryAddress add12 = new GeneralDeliveryAddress(add7);
		TelecomAddress add13 = new TelecomAddress("+54", "(9)", 246, 147437238, 233, "mobile", "2019-12-31",
				"2024-10-11");
		GeographicAddress add14 = new GeographicAddress("9992", "Boulevard Maisonneuve", "Chongqing", "China",
				"H4A 5E4", "1010-01-01", "9999-01-01");
		WebPageAddress add15 = new WebPageAddress("www.amazon.com", "2010-01-01", "2040-01-01");
		//put objects in array
		add[0] = add1;
		add[1] = add2;
		add[2] = add3;
		add[3] = add4;
		add[4] = add6;
		add[5] = add7;
		add[6] = add8;
		add[7] = add9;
		add[8] = add10;
		add[9] = add11;
		add[10] = add12;
		add[11] = add13;
		add[12] = add14;
		add[13] = add5;
		add[14] = add15;
		//PRINT ARRAY
		for (int i = 0; i < 15; i++) {
			System.out.println(add[i]);
		}
		//TEST EQUALS()
		System.out.println("-Testing the equality of add2 and add4 (true means equal and false means not equal): "
				+ add2.equals(add4) + "\n");
		//traceObsoleteAddresses()
		System.out.println("Check address is obselete on 2020-01-01");
		traceObsoleteAddresses(add, 2020, 01, 01);
		System.out.println();
		System.out.println("Check address is obselete on 2017-05-28");
		traceObsoleteAddresses(add, 2017, 05, 28);
		System.out.println();

	}

	//FUNCTION traceObsoleteAddresses()
	private static void traceObsoleteAddresses(Address[] add, int year, int month, int day) {
		for (int i = 0; i < add.length; i++) {
			String[] from = add[i].getValidFrom().split("-");
			String[] to = add[i].getValidTo().split("-");

			
			if (Integer.valueOf(to[0]) < year || Integer.valueOf(from[0]) > year)
				System.out.println("Address " + i + " is obsolete");
			else if (Integer.valueOf(from[0]) < year && Integer.valueOf(to[0]) > year) {
				continue;
			} else {
				if (Integer.valueOf(from[0]) <= year && Integer.valueOf(to[0]) == year) {
					if (Integer.valueOf(to[1]) < month || Integer.valueOf(from[1]) > month)
						System.out.println("Address " + i + " is obsolete");
					else if (Integer.valueOf(to[1]) > month) {
						continue;
					} else {
						if (Integer.valueOf(from[1]) <= month && Integer.valueOf(to[1]) == month) {
							if (Integer.valueOf(to[2]) < day || Integer.valueOf(from[2]) > day)
								System.out.println("Address " + i + " is obsolete");
							else if (Integer.valueOf(to[1]) >= day) {
								continue;
							}
						} else if (Integer.valueOf(from[1]) <= month && Integer.valueOf(to[1]) > month) {
							if (Integer.valueOf(from[2]) > day)
								System.out.println("Address " + i + " is obsolete");
							else
								continue;
						} else {
							System.out.println("Address " + i + " is obsolete");
						}
					}
				} else if (Integer.valueOf(from[0]) <= year && Integer.valueOf(to[0]) > year) {
					if (Integer.valueOf(from[1]) > month)
						System.out.println("Address " + i + " is obsolete");
					else
						continue;
				} else {
					System.out.println("Address " + i + " is obsolete");
				}
			}
		}

	}

}
